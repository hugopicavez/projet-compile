package ProjetCompil.Syntaxe.Src;

/**
 * Exception levée en cas d'erreur lexicale. 
 */

public class ErreurLexicale extends Exception {

}

