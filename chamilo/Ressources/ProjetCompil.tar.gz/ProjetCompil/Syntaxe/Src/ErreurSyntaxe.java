package ProjetCompil.Syntaxe.Src;

/**
 * Exception levée en cas d'erreur de syntaxe.
 */

public class ErreurSyntaxe extends Exception {

}

